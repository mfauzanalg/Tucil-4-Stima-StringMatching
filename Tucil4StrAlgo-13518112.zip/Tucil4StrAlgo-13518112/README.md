# Project Title

TUCIL 4 String Matching BM, KMP, Regex

### Prerequisites

1. python

2. nltk library install all 

3. flaks

```
Pastikan semua komponen terinstall dengan benar dan sudah disesuaikan PATH nya agar tidak terjadi gagal compile
```

## Install NLTK

in terminal pip install nltk

type python and enter

then 

">>> import nltk

">>> nltk.download ()

install all

## Running the program

1. open src folder

2. open terminal

3. run in windows -> python ProgramFlaks.py

4. run in ubuntu -> python3 ProgramFlaks.py

5. copy link provided in terminal

6. Paste in browser


## Built With

Python

NLTK library

Flaks

## Authors

Muhammad Fauzan Al-Ghifari

13518112

